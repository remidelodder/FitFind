import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KrachttrainingSpieropbouwPage } from './krachttraining-spieropbouw';

@NgModule({
  declarations: [
    KrachttrainingSpieropbouwPage,
  ],
  imports: [
    IonicPageModule.forChild(KrachttrainingSpieropbouwPage),
  ],
})
export class KrachttrainingSpieropbouwPageModule {}
