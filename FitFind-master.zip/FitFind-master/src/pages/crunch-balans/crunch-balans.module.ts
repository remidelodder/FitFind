import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrunchBalansPage } from './crunch-balans';

@NgModule({
  declarations: [
    CrunchBalansPage,
  ],
  imports: [
    IonicPageModule.forChild(CrunchBalansPage),
  ],
})
export class CrunchBalansPageModule {}
