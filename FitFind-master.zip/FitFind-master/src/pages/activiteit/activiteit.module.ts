import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ActiviteitPage } from './activiteit';

@NgModule({
  declarations: [
    ActiviteitPage,
  ],
  imports: [
    IonicPageModule.forChild(ActiviteitPage),
  ],
})
export class ActiviteitPageModule {}
