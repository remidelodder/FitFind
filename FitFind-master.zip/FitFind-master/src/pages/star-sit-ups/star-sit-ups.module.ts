import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StarSitUpsPage } from './star-sit-ups';

@NgModule({
  declarations: [
    StarSitUpsPage,
  ],
  imports: [
    IonicPageModule.forChild(StarSitUpsPage),
  ],
})
export class StarSitUpsPageModule {}
