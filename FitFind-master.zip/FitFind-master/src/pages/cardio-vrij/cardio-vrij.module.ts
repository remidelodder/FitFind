import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CardioVrijPage } from './cardio-vrij';

@NgModule({
  declarations: [
    CardioVrijPage,
  ],
  imports: [
    IonicPageModule.forChild(CardioVrijPage),
  ],
})
export class CardioVrijPageModule {}
