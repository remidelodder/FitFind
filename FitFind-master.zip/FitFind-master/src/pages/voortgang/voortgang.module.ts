import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VoortgangPage } from './voortgang';

@NgModule({
  declarations: [
    VoortgangPage,
  ],
  imports: [
    IonicPageModule.forChild(VoortgangPage),
  ],
})
export class VoortgangPageModule {}
