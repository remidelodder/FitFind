import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OefeningenPage } from './oefeningen';

@NgModule({
  declarations: [
    OefeningenPage,
  ],
  imports: [
    IonicPageModule.forChild(OefeningenPage),
  ],
})
export class OefeningenPageModule {}
