import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PlankRepsPage } from './plank-reps';

@NgModule({
  declarations: [
    PlankRepsPage,
  ],
  imports: [
    IonicPageModule.forChild(PlankRepsPage),
  ],
})
export class PlankRepsPageModule {}
