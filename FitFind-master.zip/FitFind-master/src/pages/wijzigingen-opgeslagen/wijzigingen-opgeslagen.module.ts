import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WijzigingenOpgeslagenPage } from './wijzigingen-opgeslagen';

@NgModule({
  declarations: [
    WijzigingenOpgeslagenPage,
  ],
  imports: [
    IonicPageModule.forChild(WijzigingenOpgeslagenPage),
  ],
})
export class WijzigingenOpgeslagenPageModule {}
