import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistrerenPage } from './registreren';

@NgModule({
  declarations: [
    RegistrerenPage,
  ],
  imports: [
    IonicPageModule.forChild(RegistrerenPage),
  ],
})
export class RegistrerenPageModule {}
