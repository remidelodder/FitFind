import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KrachtPage } from './kracht';

@NgModule({
  declarations: [
    KrachtPage,
  ],
  imports: [
    IonicPageModule.forChild(KrachtPage),
  ],
})
export class KrachtPageModule {}
